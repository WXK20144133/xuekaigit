package com.xiaour.spring.boot.utils.aes;



public class Env {
	
	public static final String OAPI_HOST = "https://oapi.dingtalk.com";
	public static final String OA_BACKGROUND_URL = ""; 
	public static final String CORP_ID = "ding103b3ec2abc362c135c2f4657eb6378f";
	
	public static final String CORP_SECRET = "2wZtuw6dbf4o8KY8qEY1CrRUmMn78s51jNz0PXxBm9ylVZ3Mju56BZZKeiUEnvan";
	public static final String SSO_Secret = "7d6IsFc_Vs1VmY2YFvOKRtBth7f8N-EFKtEswWDlEBN6g5NfWwJ7InLW5OoeJFCV";

	
	public static String suiteTicket; 
	public static String authCode; 
	public static String suiteToken; 

	public static final String CREATE_SUITE_KEY = "suite4xxxxxxxxxxxxxxx";
	public static final String SUITE_KEY = "";
	public static final String SUITE_SECRET = "";
	public static final String TOKEN = "";
	public static final String ENCODING_AES_KEY = "";
	
	
	
	public static final String SNS_APP_ID = "dingoates0filrnnxqbetd";
	public static final String SNS_APP_SECRET = "KQgORLyXYMcnfE1C6iXVSv1epdfiH_xiWARV6lApPgcAFOTr1SLzAFpr3ErBkpBQ";

	
}
