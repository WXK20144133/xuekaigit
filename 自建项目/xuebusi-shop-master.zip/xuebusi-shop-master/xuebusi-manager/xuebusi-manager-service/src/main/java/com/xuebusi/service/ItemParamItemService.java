package com.xuebusi.service;

public interface ItemParamItemService {

	String getItemParamByItemId(Long itemId);
}
