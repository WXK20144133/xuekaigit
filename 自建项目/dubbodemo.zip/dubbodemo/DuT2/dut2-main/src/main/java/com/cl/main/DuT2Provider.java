package com.cl.main;

/**
 * Created by TF on 2016/8/8.
 */
public class DuT2Provider {

    public static void main(String[] args){
        com.alibaba.dubbo.container.Main.main(args);
    }
}
