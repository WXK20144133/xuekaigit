package com.cl.api.service;

/**
 * Created by TF on 2016/8/4.
 */
public interface Dut2Service {

   String test();

}
