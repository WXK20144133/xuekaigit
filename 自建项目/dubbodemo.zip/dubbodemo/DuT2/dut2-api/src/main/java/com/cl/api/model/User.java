package com.cl.api.model;

/**
 * Created by TF on 2016/8/4.
 */
public class User {
}
