package iflyer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by liuxin on 17/1/20.
 */
@SpringBootApplication
public class IflyerApplication {

    public static void main(String[] args) {
        SpringApplication.run(IflyerApplication.class, args);
    }
}
