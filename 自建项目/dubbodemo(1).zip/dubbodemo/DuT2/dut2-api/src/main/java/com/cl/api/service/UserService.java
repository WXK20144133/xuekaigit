package com.cl.api.service;

/**
 * Created by TF on 2016/8/9.
 */
public interface UserService {

    String user();
}
