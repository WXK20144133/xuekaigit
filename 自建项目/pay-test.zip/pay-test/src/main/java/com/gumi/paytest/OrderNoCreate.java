package com.gumi.paytest;

public class OrderNoCreate {

    public static int orderNo = 0;
}
